/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2020 Mariusz Boloz (https://mb2themes.com)
 * @license   Commercial https://themeforest.net/licenses
 *
 */


jQuery(document).ready(function($){


	/*-----------------------------------------------------------*/
	/*	Init bootstrap tooltip and popover
	/*-----------------------------------------------------------*/
	$('[data-toggle="tooltip"]').tooltip();
	$('[data-toggle="popover"]').popover();


});
